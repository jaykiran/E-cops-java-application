/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class login {
    
}
// jlabelClose = close form on jlabel click
private void jLabelCloseMouseClicked(java.awt.event.MouseEvent evt) {                                         
        System.exit(0);

    }   


// jlabelMin = minimize form on jlabel click
private void jLabelMinMouseClicked(java.awt.event.MouseEvent evt) {                                       

        this.setState(JFrame.ICONIFIED);

    }


// jLabelRegister = open login form on jlabel click (on register form)
private void jLabelRegisterMouseClicked(java.awt.event.MouseEvent evt) {                                            
        LoginForm lgf = new LoginForm();
        lgf.setVisible(true);
        lgf.pack();
        lgf.setLocationRelativeTo(null);
        lgf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }

// jLabelRegister = open login form on jlabel click  (on login form)
private void jLabelRegisterMouseClicked(java.awt.event.MouseEvent evt) {                                            
        RegisterForm rgf = new RegisterForm();
        rgf.setVisible(true);
        rgf.pack();
        rgf.setLocationRelativeTo(null);
        rgf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       this.dispose();
    } 
