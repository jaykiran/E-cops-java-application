/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectivity;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author ADMIN
 */
public class java {
     private static final String user = "arun1";
     private static final String pass = "aruna1";
     private static final String url = "jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=convertToNull";
     public static void  main(String ags[]){
         try{
            conn = DriverManager.getConnection(url,user,pass);
            stmt =conn.createStatement();
            System.out.println("connected to database");
        }
        catch(SQLException e)
        {
            System.out.println("error in connecting database");
        }
     }
    
}
